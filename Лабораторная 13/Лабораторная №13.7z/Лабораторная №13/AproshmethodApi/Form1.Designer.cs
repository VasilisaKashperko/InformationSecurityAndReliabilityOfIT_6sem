﻿
namespace AproshmethodApi
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.open_document = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.Encrypt_information = new System.Windows.Forms.Button();
            this.Word = new System.Windows.Forms.TextBox();
            this.status = new System.Windows.Forms.Label();
            this.Decryption_information = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Word8 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // open_document
            // 
            this.open_document.BackColor = System.Drawing.Color.LightBlue;
            this.open_document.Cursor = System.Windows.Forms.Cursors.Hand;
            this.open_document.Font = new System.Drawing.Font("GeoSlab703 Md BT", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.open_document.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.open_document.Location = new System.Drawing.Point(506, 101);
            this.open_document.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.open_document.Name = "open_document";
            this.open_document.Size = new System.Drawing.Size(329, 57);
            this.open_document.TabIndex = 0;
            this.open_document.Text = "Выбрать файл";
            this.open_document.UseVisualStyleBackColor = false;
            this.open_document.Click += new System.EventHandler(this.button1_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 16);
            this.label1.TabIndex = 1;
            // 
            // Encrypt_information
            // 
            this.Encrypt_information.BackColor = System.Drawing.Color.PaleGreen;
            this.Encrypt_information.Font = new System.Drawing.Font("GeoSlab703 Md BT", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Encrypt_information.Location = new System.Drawing.Point(245, 366);
            this.Encrypt_information.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Encrypt_information.Name = "Encrypt_information";
            this.Encrypt_information.Size = new System.Drawing.Size(274, 57);
            this.Encrypt_information.TabIndex = 2;
            this.Encrypt_information.Text = "Зашифровать";
            this.Encrypt_information.UseVisualStyleBackColor = false;
            this.Encrypt_information.Click += new System.EventHandler(this.Encrypt_information_Click);
            // 
            // Word
            // 
            this.Word.Location = new System.Drawing.Point(166, 210);
            this.Word.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Word.Multiline = true;
            this.Word.Name = "Word";
            this.Word.Size = new System.Drawing.Size(1042, 99);
            this.Word.TabIndex = 3;
            // 
            // status
            // 
            this.status.AutoSize = true;
            this.status.Location = new System.Drawing.Point(675, 12);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(0, 16);
            this.status.TabIndex = 11;
            // 
            // Decryption_information
            // 
            this.Decryption_information.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Decryption_information.Font = new System.Drawing.Font("GeoSlab703 Md BT", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Decryption_information.Location = new System.Drawing.Point(844, 365);
            this.Decryption_information.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Decryption_information.Name = "Decryption_information";
            this.Decryption_information.Size = new System.Drawing.Size(274, 58);
            this.Decryption_information.TabIndex = 13;
            this.Decryption_information.Text = "Дешифровать";
            this.Decryption_information.UseVisualStyleBackColor = false;
            this.Decryption_information.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(27, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(148, 23);
            this.label5.TabIndex = 16;
            this.label5.Text = "Путь к файлу:";
            // 
            // Word8
            // 
            this.Word8.AutoSize = true;
            this.Word8.Location = new System.Drawing.Point(163, 361);
            this.Word8.Name = "Word8";
            this.Word8.Size = new System.Drawing.Size(0, 16);
            this.Word8.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(37, 389);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 16);
            this.label8.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(309, 459);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 16);
            this.label9.TabIndex = 23;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(27, 210);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 23);
            this.label10.TabIndex = 24;
            this.label10.Text = "Сообщение";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(346, 476);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(862, 93);
            this.textBox1.TabIndex = 28;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 473);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(248, 23);
            this.label2.TabIndex = 24;
            this.label2.Text = "Полученное сообщение";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(27, 118);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(391, 23);
            this.label7.TabIndex = 32;
            this.label7.Text = "Выберите текстовый файл-контейнер";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1270, 594);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Word8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Decryption_information);
            this.Controls.Add(this.status);
            this.Controls.Add(this.Word);
            this.Controls.Add(this.Encrypt_information);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.open_document);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Text Steganography";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button open_document;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Encrypt_information;
        private System.Windows.Forms.TextBox Word;
        private System.Windows.Forms.Label status;
        private System.Windows.Forms.Button Decryption_information;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Word8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
    }
}

